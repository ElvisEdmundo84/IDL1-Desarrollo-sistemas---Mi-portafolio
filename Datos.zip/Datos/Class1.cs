﻿namespace Datos
{
    public class Class1
    {

    }
}
