﻿namespace Infraestructura
{
    public class Class1
    {

    }
}
