﻿namespace IDL1___Arquitectura_multicapa
{
    public class Class1
    {

    }
}
