﻿namespace Negocio
{
    public class Class1
    {

    }
}
